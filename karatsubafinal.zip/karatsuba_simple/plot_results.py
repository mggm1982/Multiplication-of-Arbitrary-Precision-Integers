# draws graphs from the csv files made by the C++ program
# run the C++ program (menu option 2) first, then:  python plot_results.py
import csv
import matplotlib.pyplot as plt

def read(name):
    f = open(name)
    rows = list(csv.DictReader(f))
    f.close()
    data = {}
    for key in rows[0]:
        data[key] = [float(r[key]) for r in rows]
    return data

# graph 1: which cutoff is best
t = read("results_tuning.csv")
best = t["total_ms"].index(min(t["total_ms"]))
plt.figure()
plt.plot(t["cutoff"], t["total_ms"], marker="o")
plt.plot(t["cutoff"][best], t["total_ms"][best], marker="o", color="red", markersize=10, label="best cutoff = " + str(int(t["cutoff"][best])))
plt.xscale("log")
plt.xlabel("cutoff (digits)")
plt.ylabel("total time on training data (ms)")
plt.title("Choosing the cutoff")
plt.legend()
plt.grid(True)
plt.savefig("graph_cutoff.png", dpi=150)

# graph 2: school method against Karatsuba
r = read("results_testing.csv")
plt.figure()
plt.plot(r["digits"], r["school_ms"], marker="o", label="school method")
plt.plot(r["digits"], r["karatsuba_cutoff4_ms"], marker="o", label="Karatsuba, cutoff 4")
plt.plot(r["digits"], r["karatsuba_best_ms"], marker="o", label="Karatsuba, best cutoff")
plt.xscale("log")
plt.yscale("log")
plt.xlabel("number of digits")
plt.ylabel("time (ms)")
plt.title("Running time on the testing data")
plt.legend()
plt.grid(True)
plt.savefig("graph_runtime.png", dpi=150)

# graph 3: one long number and one short number
u = read("results_unbalanced.csv")
plt.figure()
plt.plot(u["short_digits"], u["school_ms"], marker="o", label="school method")
plt.plot(u["short_digits"], u["karatsuba_no_chunking_ms"], marker="o", label="Karatsuba, no chunking")
plt.plot(u["short_digits"], u["karatsuba_chunking_ms"], marker="o", label="Karatsuba, chunking")
plt.xscale("log")
plt.yscale("log")
plt.xlabel("digits in the short number (the long one has 20000)")
plt.ylabel("time (ms)")
plt.title("Numbers with very different lengths")
plt.legend()
plt.grid(True)
plt.savefig("graph_uneven.png", dpi=150)
print("graphs saved")
