// Karatsuba multiplication of very large integers
// compared with the normal school method

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace std;

// below this many digits we use the normal method
int cutoff = 32;

// to stop the compiler from skipping the multiplications while timing
int dummy = 0;

// true = a very long number is cut into pieces when the other one is short
bool chunking = true;

int passed = 0;
int totalTests = 0;

// a number with a sign (used for the negative numbers)
struct SignedNumber {
    vector<int> digits;   // the digits, last digit first
    bool negative;        // true if the number is below zero
};

// A number is stored in a vector of digits, LAST digit first.
// Example: 1234 is stored as 4 3 2 1

// removes extra zeros at the end of the vector (the front of the number)
void removeZeros(vector<int> &a) {
    while (a.size() > 1 && a[a.size() - 1] == 0) {
        a.pop_back();
    }
}

vector<int> stringToNumber(string s) {
    vector<int> a;
    for (int i = s.size() - 1; i >= 0; i--) {
        a.push_back(s[i] - '0');
    }
    removeZeros(a);
    return a;
}

string numberToString(vector<int> a) {
    string s = "";
    for (int i = a.size() - 1; i >= 0; i--) {
        s = s + char('0' + a[i]);
    }
    return s;
}

bool isNumber(string s) {
    if (s.size() == 0) {
        return false;
    }
    int n = s.size();
    for (int i = 0; i < n; i++) {
        if (s[i] < '0' || s[i] > '9') {
            return false;
        }
    }
    return true;
}

// same as isNumber but a minus sign is allowed at the start
bool isSignedNumber(string s) {
    if (s.size() > 0 && s[0] == '-') {
        return isNumber(s.substr(1));
    }
    return isNumber(s);
}

// a + b
vector<int> add(vector<int> a, vector<int> b) {
    int na = a.size();
    int nb = b.size();
    int n = na;
    if (nb > n) {
        n = nb;
    }

    vector<int> result;
    int carry = 0;
    for (int i = 0; i < n; i++) {
        int sum = carry;
        if (i < na) {
            sum = sum + a[i];
        }
        if (i < nb) {
            sum = sum + b[i];
        }
        result.push_back(sum % 10);
        carry = sum / 10;
    }
    if (carry > 0) {
        result.push_back(carry);
    }
    return result;
}

// a - b  (a must be bigger than or equal to b)
vector<int> subtract(vector<int> a, vector<int> b) {
    int na = a.size();
    int nb = b.size();

    vector<int> result;
    int borrow = 0;
    for (int i = 0; i < na; i++) {
        int diff = a[i] - borrow;
        if (i < nb) {
            diff = diff - b[i];
        }
        if (diff < 0) {
            diff = diff + 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        result.push_back(diff);
    }
    removeZeros(result);
    return result;
}

// multiplies a number by 10^m (puts m zeros at the end of the number)
vector<int> shiftLeft(vector<int> a, int m) {
    vector<int> result;
    for (int i = 0; i < m; i++) {
        result.push_back(0);
    }
    int n = a.size();
    for (int i = 0; i < n; i++) {
        result.push_back(a[i]);
    }
    return result;
}

// normal multiplication, the way we do it on paper
vector<int> schoolbook(vector<int> a, vector<int> b) {
    int na = a.size();
    int nb = b.size();

    vector<int> result(na + nb, 0);
    for (int i = 0; i < na; i++) {
        int carry = 0;
        for (int j = 0; j < nb; j++) {
            int current = result[i + j] + a[i] * b[j] + carry;
            result[i + j] = current % 10;
            carry = current / 10;
        }
        result[i + nb] = carry;
    }
    removeZeros(result);
    return result;
}

// we need this line because multiplyUneven calls karatsuba
// and karatsuba calls multiplyUneven
vector<int> karatsuba(vector<int> a, vector<int> b);

// adds the number "part" into "result", starting at position "start"
// (the same as adding part * 10^start)
void addAt(vector<int> &result, vector<int> part, int start) {
    int np = part.size();
    int carry = 0;
    int i = 0;
    while (i < np || carry > 0) {
        int pos = start + i;
        while (pos >= (int)result.size()) {
            result.push_back(0);
        }
        int sum = result[pos] + carry;
        if (i < np) {
            sum = sum + part[i];
        }
        result[pos] = sum % 10;
        carry = sum / 10;
        i++;
    }
}

// used when one number is much longer than the other
// the long number is cut into pieces as long as the short one,
// every piece is multiplied by the short number and the answers are added
vector<int> multiplyUneven(vector<int> big, vector<int> small) {
    int nbig = big.size();
    int nsmall = small.size();

    vector<int> result(nbig + nsmall + 1, 0);
    for (int start = 0; start < nbig; start = start + nsmall) {
        vector<int> piece;
        for (int i = start; i < start + nsmall && i < nbig; i++) {
            piece.push_back(big[i]);
        }
        removeZeros(piece);
        addAt(result, karatsuba(piece, small), start);
    }
    removeZeros(result);
    return result;
}

// Karatsuba multiplication
// split both numbers into a low part and a high part:
//   a = a1 * 10^m + a0       b = b1 * 10^m + b0
// then a * b = z2 * 10^(2m) + z1 * 10^m + z0
//   z0 = a0 * b0
//   z2 = a1 * b1
//   z1 = (a0 + a1) * (b0 + b1) - z0 - z2
// so only 3 multiplications are needed instead of 4
vector<int> karatsuba(vector<int> a, vector<int> b) {
    int na = a.size();
    int nb = b.size();
    int n = na;
    if (nb > n) {
        n = nb;
    }

    // small numbers: normal method is faster
    if (n <= cutoff || na == 1 || nb == 1) {
        return schoolbook(a, b);
    }

    // one number is much longer than the other
    if (chunking && na >= 2 * nb) {
        return multiplyUneven(a, b);
    }
    if (chunking && nb >= 2 * na) {
        return multiplyUneven(b, a);
    }

    int m = n / 2;

    // break a and b into low and high parts
    vector<int> a0, a1, b0, b1;
    for (int i = 0; i < na; i++) {
        if (i < m) {
            a0.push_back(a[i]);
        } else {
            a1.push_back(a[i]);
        }
    }
    for (int i = 0; i < nb; i++) {
        if (i < m) {
            b0.push_back(b[i]);
        } else {
            b1.push_back(b[i]);
        }
    }
    // if a number is too short it has no high part
    if (a1.size() == 0) {
        a1.push_back(0);
    }
    if (b1.size() == 0) {
        b1.push_back(0);
    }
    removeZeros(a0);
    removeZeros(a1);
    removeZeros(b0);
    removeZeros(b1);

    vector<int> z0 = karatsuba(a0, b0);
    vector<int> z2 = karatsuba(a1, b1);
    vector<int> z1 = karatsuba(add(a0, a1), add(b0, b1));
    z1 = subtract(z1, z0);
    z1 = subtract(z1, z2);

    vector<int> result = add(z0, shiftLeft(z1, m));
    result = add(result, shiftLeft(z2, 2 * m));
    removeZeros(result);
    return result;
}

// ---------- numbers with a sign ----------

SignedNumber stringToSigned(string s) {
    SignedNumber x;
    x.negative = false;
    if (s[0] == '-') {
        x.negative = true;
        s = s.substr(1);
    }
    x.digits = stringToNumber(s);
    if (x.digits.size() == 1 && x.digits[0] == 0) {
        x.negative = false;   // zero has no sign
    }
    return x;
}

string signedToString(SignedNumber x) {
    string s = numberToString(x.digits);
    if (x.negative) {
        s = "-" + s;
    }
    return s;
}

SignedNumber multiplySigned(SignedNumber a, SignedNumber b) {
    SignedNumber result;
    result.digits = karatsuba(a.digits, b.digits);
    // the answer is negative only when exactly one number is negative
    result.negative = (a.negative != b.negative);
    if (result.digits.size() == 1 && result.digits[0] == 0) {
        result.negative = false;
    }
    return result;
}

// ---------- testing the code ----------

void check(bool ok, string name) {
    totalTests++;
    if (ok) {
        passed++;
    } else {
        cout << "FAILED: " << name << endl;
    }
}

// makes a random number with the given number of digits
string randomNumber(int length) {
    string s = "";
    s = s + char('1' + rand() % 9);
    for (int i = 1; i < length; i++) {
        s = s + char('0' + rand() % 10);
    }
    return s;
}

int digitSum(vector<int> a) {
    int sum = 0;
    int n = a.size();
    for (int i = 0; i < n; i++) {
        sum = sum + a[i];
    }
    return sum;
}

void runTests() {
    cout << "Checking that the multiplication is correct..." << endl;
    int oldCutoff = cutoff;
    cutoff = 4;   // small cutoff so that Karatsuba really gets used

    // an example with a known answer
    vector<int> x = stringToNumber("12345678901234567890");
    vector<int> y = stringToNumber("98765432109876543210");
    check(numberToString(karatsuba(x, y)) == "1219326311370217952237463801111263526900", "known answer");
    check(numberToString(karatsuba(x, stringToNumber("0"))) == "0", "multiply by zero");
    check(numberToString(karatsuba(x, stringToNumber("1"))) == "12345678901234567890", "multiply by one");

    // negative numbers
    check(signedToString(multiplySigned(stringToSigned("-3"), stringToSigned("4"))) == "-12", "negative times positive");
    check(signedToString(multiplySigned(stringToSigned("-3"), stringToSigned("-4"))) == "12", "negative times negative");
    check(signedToString(multiplySigned(stringToSigned("-5"), stringToSigned("0"))) == "0", "zero has no sign");
    check(signedToString(multiplySigned(stringToSigned("-12345678901234567890"), stringToSigned("98765432109876543210"))) == "-1219326311370217952237463801111263526900", "big negative");

    // numbers with only 9s have the most carrying
    int lengths[4] = {1, 10, 100, 500};
    for (int i = 0; i < 4; i++) {
        vector<int> nines = stringToNumber(string(lengths[i], '9'));
        check(karatsuba(nines, nines) == schoolbook(nines, nines), "all nines");
    }

    // random numbers, both methods must give the same answer
    for (int round = 0; round < 2; round++) {
        if (round == 1) {
            cutoff = 10;
        }
        bool allGood = true;
        for (int t = 0; t < 100; t++) {
            vector<int> a = stringToNumber(randomNumber(1 + rand() % 300));
            vector<int> b = stringToNumber(randomNumber(1 + rand() % 300));
            if (karatsuba(a, b) != schoolbook(a, b)) {
                allGood = false;
            }
        }
        check(allGood, "random numbers");
    }

    // one number very short and the other very long, with and without chunking
    for (int mode = 0; mode < 2; mode++) {
        chunking = (mode == 1);
        bool allGood = true;
        for (int t = 0; t < 100; t++) {
            vector<int> a = stringToNumber(randomNumber(1 + rand() % 30));
            vector<int> b = stringToNumber(randomNumber(200 + rand() % 600));
            if (karatsuba(a, b) != schoolbook(a, b)) {
                allGood = false;
            }
            if (karatsuba(b, a) != schoolbook(b, a)) {
                allGood = false;
            }
        }
        check(allGood, "very different lengths");
    }
    chunking = true;

    // a * (b + c) must be same as a*b + a*c
    vector<int> p = stringToNumber(randomNumber(400));
    vector<int> q = stringToNumber(randomNumber(350));
    vector<int> r = stringToNumber(randomNumber(380));
    check(karatsuba(p, add(q, r)) == add(karatsuba(p, q), karatsuba(p, r)), "a*(b+c)");

    // casting out nines on big numbers:
    // (digit sum of a * digit sum of b) and the digit sum of the answer
    // must leave the same remainder when divided by 9
    vector<int> big1 = stringToNumber(randomNumber(2000));
    vector<int> big2 = stringToNumber(randomNumber(1500));
    vector<int> bigProduct = karatsuba(big1, big2);
    check((digitSum(big1) % 9) * (digitSum(big2) % 9) % 9 == digitSum(bigProduct) % 9, "casting out nines");

    cutoff = oldCutoff;
    cout << passed << " of " << totalTests << " tests passed." << endl;
}

// ---------- measuring the time ----------

// method 1 = school method, method 2 = Karatsuba
// returns the time of one multiplication in milliseconds
double measure(int method, vector<int> a, vector<int> b) {
    int work = a.size() * b.size();
    int repeats = 1 + 20000000 / work;   // small jobs are repeated more times

    clock_t start = clock();
    for (int r = 0; r < repeats; r++) {
        vector<int> c;
        if (method == 1) {
            c = schoolbook(a, b);
        } else {
            c = karatsuba(a, b);
        }
        dummy = dummy + c.size();
    }
    clock_t end = clock();

    return (end - start) * 1000.0 / CLOCKS_PER_SEC / repeats;
}

// writes one file for each size, with two random numbers inside
bool makeFiles(string folder, int sizes[], int count) {
    for (int i = 0; i < count; i++) {
        string path = folder + "/pair_" + to_string(sizes[i]) + ".txt";
        ofstream file(path.c_str());
        if (!file) {
            cout << "Could not create " << path << endl;
            cout << "Make a folder named " << folder << " next to the program." << endl;
            return false;
        }
        file << randomNumber(sizes[i]) << endl;
        file << randomNumber(sizes[i]) << endl;
    }
    return true;
}

// reads the two numbers from a file
void readFile(string folder, int size, vector<int> &a, vector<int> &b) {
    string path = folder + "/pair_" + to_string(size) + ".txt";
    ifstream file(path.c_str());
    string s1, s2;
    file >> s1 >> s2;
    a = stringToNumber(s1);
    b = stringToNumber(s2);
}

void runExperiments() {
    int trainingSizes[4] = {1000, 2000, 5000, 10000};
    int testingSizes[7] = {100, 500, 1000, 2000, 5000, 10000, 20000};

    // different seeds so training and testing numbers are different
    srand(1);
    if (!makeFiles("training_data", trainingSizes, 4)) {
        return;
    }
    srand(2);
    if (!makeFiles("testing_data", testingSizes, 7)) {
        return;
    }

    // step 1: find the best cutoff using the training data
    cout << endl << "Step 1: finding the best cutoff (training data)" << endl;
    int candidates[16] = {8, 16, 24, 32, 48, 64, 96, 128, 160, 192, 256, 320, 384, 512, 768, 1024};
    ofstream tuningFile("results_tuning.csv");
    tuningFile << "cutoff,total_ms" << endl;

    int bestCutoff = candidates[0];
    double bestTotal = -1;
    for (int c = 0; c < 16; c++) {
        cutoff = candidates[c];
        double total = 0;
        for (int i = 0; i < 4; i++) {
            vector<int> a, b;
            readFile("training_data", trainingSizes[i], a, b);
            total = total + measure(2, a, b);
        }
        cout << "cutoff " << cutoff << " : " << total << " ms" << endl;
        tuningFile << cutoff << "," << total << endl;
        if (bestTotal < 0 || total < bestTotal) {
            bestTotal = total;
            bestCutoff = cutoff;
        }
    }
    cout << "Best cutoff = " << bestCutoff << " digits" << endl;

    // step 2: compare the methods using the testing data
    cout << endl << "Step 2: school method vs Karatsuba (testing data)" << endl;
    cout << "digits\tschool(ms)\tkaratsuba cutoff 4(ms)\tkaratsuba best cutoff(ms)" << endl;
    ofstream testFile("results_testing.csv");
    testFile << "digits,school_ms,karatsuba_cutoff4_ms,karatsuba_best_ms" << endl;

    double schoolTimes[7];
    double karaTimes[7];
    for (int i = 0; i < 7; i++) {
        vector<int> a, b;
        readFile("testing_data", testingSizes[i], a, b);

        schoolTimes[i] = measure(1, a, b);

        cutoff = 4;
        double slow = measure(2, a, b);

        cutoff = bestCutoff;
        karaTimes[i] = measure(2, a, b);

        if (schoolbook(a, b) != karatsuba(a, b)) {
            cout << "ERROR: answers are different for " << testingSizes[i] << " digits" << endl;
        }

        cout << testingSizes[i] << "\t" << schoolTimes[i] << "\t\t" << slow << "\t\t\t" << karaTimes[i] << endl;
        testFile << testingSizes[i] << "," << schoolTimes[i] << "," << slow << "," << karaTimes[i] << endl;
    }

    // step 3: how fast does the time grow?
    // if time grows like n^k then k = log(time2/time1) / log(n2/n1)
    cout << endl << "Step 3: how the time grows (time ~ n^k), from 1000 to 20000 digits" << endl;
    double kSchool = log(schoolTimes[6] / schoolTimes[2]) / log(20000.0 / 1000.0);
    double kKara = log(karaTimes[6] / karaTimes[2]) / log(20000.0 / 1000.0);
    cout << "school method: k = " << kSchool << "  (expected about 2)" << endl;
    cout << "karatsuba:     k = " << kKara << "  (expected about 1.58)" << endl;

    // step 4: one long number and one short number
    cout << endl << "Step 4: very different lengths (the long number has 20000 digits)" << endl;
    cout << "short\tschool(ms)\tno chunking(ms)\tchunking(ms)" << endl;
    ofstream unevenFile("results_unbalanced.csv");
    unevenFile << "short_digits,school_ms,karatsuba_no_chunking_ms,karatsuba_chunking_ms" << endl;

    cutoff = bestCutoff;
    srand(3);
    vector<int> longNumber = stringToNumber(randomNumber(20000));
    int shortSizes[5] = {10, 100, 1000, 5000, 20000};
    for (int i = 0; i < 5; i++) {
        vector<int> shortNumber = stringToNumber(randomNumber(shortSizes[i]));
        double t1 = measure(1, longNumber, shortNumber);
        chunking = false;
        double t2 = measure(2, longNumber, shortNumber);
        chunking = true;
        double t3 = measure(2, longNumber, shortNumber);
        cout << shortSizes[i] << "\t" << t1 << "\t\t" << t2 << "\t\t" << t3 << endl;
        unevenFile << shortSizes[i] << "," << t1 << "," << t2 << "," << t3 << endl;
    }

    cout << endl << "Results saved in results_tuning.csv, results_testing.csv and results_unbalanced.csv" << endl;
}

void multiplyTwo() {
    string s1, s2;
    cout << "Enter first number: ";
    cin >> s1;
    cout << "Enter second number: ";
    cin >> s2;
    if (!isSignedNumber(s1) || !isSignedNumber(s2)) {
        cout << "Please enter only digits (0-9), with an optional - at the start." << endl;
        return;
    }
    SignedNumber product = multiplySigned(stringToSigned(s1), stringToSigned(s2));
    cout << "Product = " << signedToString(product) << endl;
}

int main() {
    srand(12345);
    runTests();

    int choice = 0;
    while (choice != 3) {
        cout << endl;
        cout << "1. Multiply two numbers" << endl;
        cout << "2. Run the speed comparison" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        if (!cin) {
            break;
        }
        if (choice == 1) {
            multiplyTwo();
        } else if (choice == 2) {
            runExperiments();
        }
    }
    return 0;
}
